此文件夹用于放置Windows原生引导路径

- Windows
  - Microsoft
  - BOOT

- 将指定文件夹移动至此目录即可开启单磁盘双系统

- [更多信息请点击](https://hackintool.vercel.app/%E5%9F%BA%E7%A1%80%E7%AF%87/%E5%8F%8C%E7%B3%BB%E7%BB%9F.html#%E5%8F%8C%E7%B3%BB%E7%BB%9F%E5%B8%B8%E8%A7%81%E6%95%85%E9%9A%9C%E4%BF%AE%E5%A4%8D)